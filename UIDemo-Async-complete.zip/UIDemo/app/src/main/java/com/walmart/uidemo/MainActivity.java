package com.walmart.uidemo;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    public void startService(View view){
        Log.d("message", "starting service");
        Intent intent = new Intent(getApplicationContext(), MyService.class);
        startService(intent);
    }

    public void sendMessage(View view){
//        Intent intent = new Intent("com.walmart.action.fetched");
//        sendBroadcast(intent);
//        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
//        localBroadcastManager.sendBroadcast(intent);
        Log.d("testing", Thread.currentThread()+"");
        CounterAsyncTask task = new CounterAsyncTask();
        task.execute(new Integer(6));
        task.cancel(true);
    }

    public class CounterAsyncTask extends AsyncTask<Integer, Integer, Integer> {
        @Override
        protected void onCancelled() {
            super.onCancelled();

        }

        @Override
        protected void onProgressUpdate(Integer[] values) {
            super.onProgressUpdate(values);
            Log.d("test", "called with ="+values[0]+ Thread.currentThread());
            final TextView textView = findViewById(R.id.text1);
            textView.setText(values[0]+"");
        }

        @Override
        protected void onPostExecute(Integer finalValue) {
            super.onPostExecute(finalValue);
            Log.d("test", "called with ="+finalValue+ Thread.currentThread());
            final TextView textView = findViewById(R.id.text1);
            textView.setText(finalValue+"");
        }

        @Override
        protected void onPreExecute() {
            Log.d("testing", Thread.currentThread()+"");
            super.onPreExecute();
        }

        @Override
        protected Integer doInBackground(Integer[] inputsFromMainThread) {
            URL url = new URL("http://it-ebooks-api.info/v1/search/jquery");
            Log.d("testing", Thread.currentThread()+"");
            int i=0;
            for (;i<(int) inputsFromMainThread[0];i++){
                publishProgress(i);
//                int j=1/0;
                try{
                    Thread.sleep(2000);
                }catch(Exception ex){

                }
//            textView.setText(i+"");
            }

            return i;
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
