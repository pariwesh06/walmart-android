package com.walmart.uidemo;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Pariwesh on 3/7/2018.
 */

public class BooksAdapter extends ArrayAdapter{
    private Context context;

    public BooksAdapter(@NonNull Context context, int resource) {
        super(context, resource);
        this.context=context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        Log.d("test", position+"");
        convertView = inflater.inflate(R.layout.row_item,parent, false);
        TextView title = convertView.findViewById(R.id.title);
        Book book = (Book)getItem(position);

        title.setText(book.title);
        TextView isbn = convertView.findViewById(R.id.isbn);
        isbn.setText(book.isbn);
        ImageView  imageView = convertView.findViewById(R.id.thumbnail);

        imageView.setImageURI(Uri.parse(book.url));
        return convertView;
    }
}
