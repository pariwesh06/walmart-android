package com.walmart.uidemo;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    ArrayAdapter booksAdapter=null;
    public void startService(View view){
        Log.d("message", "starting service");
        Intent intent = new Intent(getApplicationContext(), MyService.class);
        startService(intent);
    }

    public void sendMessage(View view){
//        Intent intent = new Intent("com.walmart.action.fetched");
//        sendBroadcast(intent);
//        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(getApplicationContext());
//        localBroadcastManager.sendBroadcast(intent);
        Log.d("testing", Thread.currentThread()+"");
        CounterAsyncTask task = new CounterAsyncTask();
        task.execute(new Integer(6));
//        task.cancel(true);
    }

    public class CounterAsyncTask extends AsyncTask<Integer, Integer, List<Book>> {
        @Override
        protected void onCancelled() {
            super.onCancelled();

        }

        @Override
        protected void onProgressUpdate(Integer[] values) {
            super.onProgressUpdate(values);
            Log.d("test", "called with ="+values[0]+ Thread.currentThread());
            final TextView textView = findViewById(R.id.text1);
            textView.setText(values[0]+"");
        }

        @Override
        protected void onPostExecute(List<Book> books) {
            booksAdapter.addAll(books);
        }

        @Override
        protected void onPreExecute() {
            Log.d("testing", Thread.currentThread()+"");
            super.onPreExecute();
        }

        @Override
        protected List<Book> doInBackground(Integer[] inputsFromMainThread) {
            List<Book> books=null;
            try {
                URL url = new URL("http://it-ebooks-api.info/v1/search/android");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    String output;
                   StringBuffer response = new StringBuffer();

                    while ((output = in.readLine()) != null) {
                        response.append(output);
                    }
                    in.close();
                    String responseText = response.toString();
//                    Log.d("response=" , responseText);
                    JSONObject root = new JSONObject(responseText);
                    JSONArray jsonarray = root.getJSONArray("Books");
                    books= new ArrayList<Book>();
                    for (int i = 0; i < jsonarray.length(); i++) {
                        JSONObject jsonobject = jsonarray.getJSONObject(i);
                        String title = jsonobject.getString("Title");
                        Book book = new Book();
                        book.title=title;
                        books.add(book);
//                        Log.d("test", "title:" + title);
                    }

                    Log.d("books list=", books.toString());
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
//                Toast.makeText()
            } catch (IOException e) {
                e.printStackTrace();
            }catch (JSONException e){
                e.printStackTrace();
            }
            return books;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        ListView booksListView = findViewById(R.id.books);
         booksAdapter = new BooksAdapter(this,android.R.layout.simple_list_item_2);
//        booksAdapter.add(new Book());
//        booksAdapter.addAll(???);
        booksListView.setAdapter(booksAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
