package com.walmart.uidemo;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Pariwesh on 3/7/2018.
 */

public class BooksAdapter extends ArrayAdapter{
    private Context context;

    public BooksAdapter(@NonNull Context context, int resource) {
        super(context, resource);
        this.context=context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        Log.d("test", position+"");
        convertView = inflater.inflate(android.R.layout.simple_list_item_1,parent, false);
        TextView textView = convertView.findViewById(android.R.id.text1);
        Book book = (Book)getItem(position);
        textView.setText(book.title);
        return convertView;
    }
}
