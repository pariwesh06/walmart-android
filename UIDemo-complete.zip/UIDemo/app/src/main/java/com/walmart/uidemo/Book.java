package com.walmart.uidemo;

/**
 * Created by Pariwesh on 3/7/2018.
 */

public class Book {
    String title;
    int isbn;
}
